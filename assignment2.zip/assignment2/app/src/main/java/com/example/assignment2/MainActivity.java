package com.example.assignment2;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashSet;

public class MainActivity extends AppCompatActivity {
    static ArrayList<Task> tasks = new ArrayList<>();
    static NoteAdapter noteAdapter;

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId() == R.id.about_us) {
            Intent intent = new Intent(getApplicationContext(),AboutMeActivity.class);
            startActivity(intent);
            return true;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ListView listView = findViewById(R.id.listView);
        FloatingActionButton fab = findViewById(R.id.fab);

        SharedPreferences sharedPreferences =
                getApplicationContext().getSharedPreferences("com.example.assignment2", Context.MODE_PRIVATE);

        HashSet<String> set = (HashSet<String>) sharedPreferences.getStringSet("tasks", null);

        if (set == null) {
            tasks.add(new Task("Example Task", "Example Description", "General", "Pending", "Example Content"));
        } else {
            for (String s : set) {
                String[] taskData = s.split(",");
                if (taskData.length == 5) {
                    tasks.add(new Task(taskData[0], taskData[1], taskData[2], taskData[3], taskData[4]));
                } else {
                    // Handle the case where taskData doesn't have the expected length
                    tasks.add(new Task("Invalid Task", "Data", "Missing", "Fields", ""));
                }
            }
        }

        noteAdapter = new NoteAdapter(this, tasks);
        listView.setAdapter(noteAdapter);

        listView.setOnItemClickListener((adapterView, view, i, l) -> {
            Intent intent = new Intent(getApplicationContext(), note_editor.class);
            intent.putExtra("taskId", i);
            startActivity(intent);
        });

        fab.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), note_editor.class);
            startActivity(intent);
        });

        listView.setOnItemLongClickListener
                (new AdapterView.OnItemLongClickListener() {
                    public boolean onItemLongClick
                            (AdapterView<?> adapterView, View view, int i, long l) {

                        final int itemToDelete = i;  // which item the user wish to delete

                        // create a new alert dialog box
                        // if the user click yes button
                        // if the the user click no button
                        new AlertDialog.Builder(MainActivity.this)
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .setTitle("Are you sure?")
                                .setMessage("Do you want to delete this note?")
                                .setPositiveButton("Yes",
                                        new DialogInterface.OnClickListener() {

                                            public void onClick(DialogInterface dialogInterface, int i) {


                                                tasks.remove(itemToDelete);
                                                // remove items on the notes array list
                                                noteAdapter.notifyDataSetChanged();
                                                // update the listview via array adapter

                                                SharedPreferences sharedPreferences =
                                                        getApplicationContext().getSharedPreferences
                                                                ("com.example.assignment2",
                                                                        Context.MODE_PRIVATE);  // open SP or file

                                                HashSet<String> set = new HashSet(MainActivity.tasks);
                                                // convert array list to hash set

                                                sharedPreferences.edit().putStringSet("notes", set).apply();
                                                // open the SP, put new data into SP, save all changes
                                                // you can edit or delete one item at one time only

                                            }
                                        }
                                )

                                .setNegativeButton("No", null)
                                .show();


                        return true;
                    }
                });
    }
}

