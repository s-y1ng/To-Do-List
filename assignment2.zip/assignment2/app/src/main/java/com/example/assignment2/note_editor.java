// note_editor.java
package com.example.assignment2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.HashSet;

public class note_editor extends AppCompatActivity {

    int taskId;
    EditText titleEditText, descriptionEditText, contentEditText;
    Spinner categorySpinner, statusSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_editor);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        titleEditText = findViewById(R.id.titleEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        categorySpinner = findViewById(R.id.categorySpinner);
        statusSpinner = findViewById(R.id.statusSpinner);
        contentEditText = findViewById(R.id.contentEditText);

        ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(this, R.array.categories, android.R.layout.simple_spinner_item);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        ArrayAdapter<CharSequence> statusAdapter = ArrayAdapter.createFromResource(this, R.array.statuses, android.R.layout.simple_spinner_item);
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(statusAdapter);

        Intent intent = getIntent();
        taskId = intent.getIntExtra("taskId", -1);

        if (taskId != -1) {
            Task task = MainActivity.tasks.get(taskId);
            titleEditText.setText(task.getTitle());
            descriptionEditText.setText(task.getDescription());
            categorySpinner.setSelection(categoryAdapter.getPosition(task.getCategory()));
            statusSpinner.setSelection(statusAdapter.getPosition(task.getStatus()));
            contentEditText.setText(task.getContent()); // Set content in the editor
        } else {
            MainActivity.tasks.add(new Task("", "", "General", "Pending", "")); // Add empty content
            taskId = MainActivity.tasks.size() - 1;
            MainActivity.noteAdapter.notifyDataSetChanged();
        }

        findViewById(R.id.saveButton).setOnClickListener(view -> {
            saveTask();
            finish();
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void saveTask() {
        Task task = MainActivity.tasks.get(taskId);
        task.setTitle(titleEditText.getText().toString());
        task.setDescription(descriptionEditText.getText().toString());
        task.setCategory(categorySpinner.getSelectedItem().toString());
        task.setStatus(statusSpinner.getSelectedItem().toString());
        task.setContent(contentEditText.getText().toString()); // Set content

        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("com.example.assignment2", Context.MODE_PRIVATE);
        HashSet<String> set = new HashSet<>();
        for (Task t : MainActivity.tasks) {
            set.add(t.getTitle() + "," + t.getDescription() + "," + t.getCategory() + "," + t.getStatus() + "," + t.getContent()); // Save content
        }
        sharedPreferences.edit().putStringSet("tasks", set).apply();

        MainActivity.noteAdapter.notifyDataSetChanged();
    }
}
