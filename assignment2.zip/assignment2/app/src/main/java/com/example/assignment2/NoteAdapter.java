// NoteAdapter.java
package com.example.assignment2;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.graphics.Color;

public class NoteAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Task> tasks;
    private LayoutInflater inflater;
    private static final int MAX_CONTENT_LENGTH = 100; // Define the maximum content length


    public NoteAdapter(Context context, ArrayList<Task> tasks) {
        this.context = context;
        this.tasks = tasks;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return tasks.size();
    }

    @Override
    public Object getItem(int position) {
        return tasks.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.note_item, parent, false);
        }

        TextView noteTextView = convertView.findViewById(R.id.noteTextView);

        Task task = tasks.get(position);
        String title = task.getTitle();
        String category = task.getCategory();
        String status = task.getStatus();
        String content = task.getContent();

        // Truncate content if it exceeds the maximum length
        if (content.length() > MAX_CONTENT_LENGTH) {
            content = content.substring(0, MAX_CONTENT_LENGTH) + "...";
        }

        String fullText = title + "\n" + category + "\n" + status + "\n" + content;
        SpannableString spannableString = new SpannableString(fullText);

        // Set the styles for the title
        spannableString.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), 0, title.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new ForegroundColorSpan(Color.parseColor("#0C1844")), 0, title.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new RelativeSizeSpan(1.5f), 0, title.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        // Set the styles for the category
        int categoryStart = title.length() + 1;
        int categoryEnd = categoryStart + category.length();
        spannableString.setSpan(new ForegroundColorSpan(Color.parseColor("#C80036")), categoryStart, categoryEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new RelativeSizeSpan(1.2f), categoryStart, categoryEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        // Set the styles for the status
        int statusStart = categoryEnd + 1;
        int statusEnd = statusStart + status.length();
        spannableString.setSpan(new ForegroundColorSpan(Color.parseColor("#FF6969")), statusStart, statusEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new RelativeSizeSpan(1.1f), statusStart, statusEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        // Set the styles for the content (no additional styling here, default size and color)
        int contentStart = statusEnd + 1;
        int contentEnd = contentStart + content.length();
        spannableString.setSpan(new RelativeSizeSpan(1.0f), contentStart, contentEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        // Apply the spannable string to the TextView
        noteTextView.setText(spannableString);

        return convertView;
        }
    }
